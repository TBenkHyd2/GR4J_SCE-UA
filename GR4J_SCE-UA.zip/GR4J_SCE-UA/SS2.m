function SS2 = SS2(I,C);
% HYDROGRAMME Rapide
% Function calculates time delay for HU2 Aorccding GR4J FORTRAN
% See GR4J Model (CEMAGREF-IRSTEA)

FI = I;
    if FI <= 0., 
        SS2=0.;
   elseif FI <= C,
                SS2=0.5*(FI/C)^(2.5);
       elseif FI < 2*C,
                SS2=1-0.5*(2-FI/C)^(2.5);
    elseif FI > C,
            SS2=1.;

    end;


   

