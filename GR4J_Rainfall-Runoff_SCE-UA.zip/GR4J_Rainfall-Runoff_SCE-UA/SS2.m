function SS2 = SS2(I,C);
% Function calculates time delay For HU2 of GR4J Model
% Copyright (C) 1999- 2017 T. benkaci . All rights reserved.
fI = I;
    if fI <= 0., 
        SS2=0.;
   elseif fI <= C,
                SS2=0.5*(fI/C)^(2.5);
       elseif fI < 2*C,
                SS2=1-0.5*(2-fI/C)^(2.5);
    elseif fI >= C,
            SS2=1.;

    end;


