%  RAINFALL-RUNOFF MODEL MODEL (GR4J WITH 4 PARAMETERS) BY TARIK BENKACI (1998-2017)
% and N. DECHEMI 
% OPTIMISATION IS SCE-UA  (DUAN et al. )')
%In the Optim Models there is: GR4J Conceptual model with SCE-UA Optimisation method (Duan et al., 1992, 1993) 
%after many epoch of optimisation Sce-UA Algorithm the model displays the
%best parameters of GR4J model.
 % Copyright (C) 1999- 2017 T. benkaci . All rights reserved.
% 
Optim_Model
% Thus the code Run optimisation Process to Search best parameters of
% Conceptual GR4j model, with 4 Parameters
%after optimisation the model displays and save the results in GR4J.xls results
%and RESULTS Text file
% Good Modelling


