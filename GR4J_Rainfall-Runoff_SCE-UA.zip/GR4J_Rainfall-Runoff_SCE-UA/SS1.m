function SS1 = SS1(I,C);
% Function calculates time delay for HU1 of GR4J Model
% Copyright (C) 1999- 2017 T. benkaci . All rights reserved.
fI = I;
    if fI <= 0., 
        SS1=0.;
    elseif fI >= C,
            SS1=1.;
    elseif fI <= C,
                SS1=(fI/C)^(2.5);
    end;
